#include <iostream>
#include <math.h>
using namespace std;

/* D�claration des Variables. */
int Div;
int nombre;
int Reste;
/* Fonction Principale modulo */
void main(void)
{
	cout << "Choisis un nombre entier s'il te plait.";
	cin >> nombre;
	cout << "Quel nombre tester comme diviseur";
	cin >> Div;
	Reste = nombre % Div;
	if (Reste == 0)
	{
		cout << nombre << " est divisible par " << Div << "!";
	}
	else
	{
		cout << nombre << " n'est pas divisible par " << Div << "!";
	}
}