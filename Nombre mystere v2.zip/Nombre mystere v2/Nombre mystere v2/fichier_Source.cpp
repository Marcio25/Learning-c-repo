#include <iostream>
#include <time.h>
using namespace std;

void main(void)    // D�claration de la fonction principale
{
	srand((int)time(NULL) );    // L'hasard
	
	// Les deux Variables.
	int nbjoueur, nbmystere;
	// Fixer la valeur du nombre mystere
	nbmystere = rand() % 501;
	int score = 0;

	do
	{
		cout << "Entrez une tentative (entre 0 et 500) : ";
		// Nombre entr� par le joueur
		cin >> nbjoueur;
		score++;

		// Comparaison avec le nombre mystere
		if (nbjoueur == nbmystere)
			cout << "Felicitations ! "
			<< "Vous avez le nombre mystere !"
		    << "Vous avez eu besoin de " << score
			<< " tentavive(s)" << endl;
		else
		{
			if (nbjoueur < nbmystere)
				cout << "Plus ! " << endl;
			else
				cout << "Moins !" << endl;
		}
	} 
	while (nbjoueur != nbmystere); 
}